'use strict';

Vue.component('w-datetime', {
  template: '<div class="datetime">\n    \n  </div>'
});