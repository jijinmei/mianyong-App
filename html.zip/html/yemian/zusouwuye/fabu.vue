<template>
	<div>
		我是发布
	</div>
</template>

<script>
	export default {
		name: 'tuijianfuwu',
		data() {
			return {
		        datas:[1,1,1,1,2,2,2,2,2]
			}
		},
		methods: {
	
               
		},
		mounted() {
       
		}
	}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>

</style>